# libraries
import numpy as np
import scipy as sp
import pandas as pd

# read data
df = pd.read_csv('data07_diabetes.csv')
X = df.iloc[:,:-1]
y = df['Y']

# boston data set
from sklearn.model_selection import train_test_split
xtrain,xtest,ytrain,ytest = train_test_split(X,y,test_size=0.75,random_state=0)

# forward feature selection
np.random.seed(0)
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
vn = list(xtrain.columns)
f_sel= []
score = []
for i in range(xtrain.shape[1]):
    s = np.zeros(len(vn))
    for j in range(len(vn)):
        v = f_sel.copy()
        v.append(vn[j])
        x = xtrain[v]
        f = LinearRegression()
        cv_score = cross_val_score(f,x,ytrain,cv=5)
        s[j] = cv_score.mean()
    v = vn[s.argmax()]
    f_sel.append(v)
    vn.remove(v)
    score.append(s.max())
    print("%02d Selected:"%i,f_sel)
    print("%02d Score   :"%i,np.round(10000*np.array(score))/10000)

# finally selected features    
f_sel_final = f_sel[:(np.array(score).argmax()+1)]

# test on the test set
from sklearn.linear_model import LinearRegression
f = LinearRegression()
f.fit(xtrain[f_sel_final],ytrain)
f.score(xtest[f_sel_final],ytest)

# comparison with the full model
f.fit(xtrain,ytrain)
f.score(xtest,ytest)


