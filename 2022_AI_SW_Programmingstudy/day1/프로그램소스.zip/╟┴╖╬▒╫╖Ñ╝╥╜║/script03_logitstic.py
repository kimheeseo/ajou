# libraries
import numpy as np
import scipy as sp
import pandas as pd
import matplotlib.pyplot as plt

# read data from file
df = pd.read_csv('data06_iris.csv')
X = df.iloc[:,:-1]
Y = df['Species']

# train & test data
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(X,Y,test_size=0.4,random_state=1) 


###########################################################
# logistic regression
###########################################################

from sklearn.linear_model import LogisticRegression

# simple logistic regression
f = LogisticRegression()
f.fit(xtrain[['Petal.Length']],ytrain)
f.coef_
f.intercept_
x = np.arange(0,10,step=0.1)
x = x.reshape((len(x),1))
yhat_prob = f.predict_proba(x)
yhat = f.predict(x)

plt.plot(xtrain[['Petal.Length']],ytrain,'go')
plt.plot(x[:,0],yhat_prob[:,1])
plt.show()

# multiple logistic regression
f = LogisticRegression()
f.fit(xtrain,ytrain)
yhat_train = f.predict(xtrain)
yhat_train_prob = f.predict_proba(xtrain)
yhat_test = f.predict(xtest)
yhat_test_prob = f.predict_proba(xtest)

pd.crosstab(ytrain,yhat_train)
pd.crosstab(ytest,yhat_test)

f.score(xtrain,ytrain)
f.score(xtest,ytest)


###########################################################
# logistic regression with StatsModels
###########################################################

import statsmodels.api as sm
X = xtrain[['Petal.Length']]
X = sm.add_constant(X)
y = ytrain
f = sm.Logit(y,X)
r = f.fit()
r.summary()

# using a full model
X = xtrain
X = sm.add_constant(X)
y = ytrain
f = sm.Logit(y,X)
r = f.fit()
r.summary()

# training set
yhat_train_prob = r.predict(X)
yhat_train = (yhat_train_prob>0.5).astype(int)
pd.crosstab(yhat_train,ytrain)

# test set
yhat_test_prob = r.predict(sm.add_constant(xtest))
yhat_test = (yhat_test_prob>0.5).astype(int)
pd.crosstab(yhat_test,ytest)

