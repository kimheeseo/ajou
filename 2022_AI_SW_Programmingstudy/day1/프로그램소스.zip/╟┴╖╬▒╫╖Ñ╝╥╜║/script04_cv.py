# libraries
import numpy as np
import scipy as sp
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

# read data from file
df = pd.read_csv('data01_iris.csv')
X = df.iloc[:,:-1]
Y = df['Species']

# separating train & test sets
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(X,Y,test_size=0.3,random_state=0) 

# K-fold CV
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
f = LogisticRegression()
f.fit(xtrain,ytrain)
f.score(xtrain,ytrain)
f.score(xtest,ytest)
s = cross_val_score(f,xtrain,ytrain,cv=3)
s.mean()

# Validation set
xtemp, xtest, ytemp, ytest = train_test_split(X,Y,test_size=0.3,random_state=0) 
xtrain, xval, ytrain, yval = train_test_split(xtemp,ytemp,test_size=0.5,random_state=1) 
from sklearn.linear_model import LogisticRegression
f = LogisticRegression()
f.fit(xtrain,ytrain)
f.score(xtrain,ytrain)
f.score(xval,yval)
f.score(xtest,ytest)

