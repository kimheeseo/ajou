# libraries
import numpy as np
import scipy as sp
import pandas as pd

# read data
df = pd.read_csv('data05_boston.csv')
X = df.iloc[:,:-1]
y = df['medv']
from sklearn.model_selection import train_test_split
xtrain,xtest,ytrain,ytest = train_test_split(X,y,test_size=0.5,random_state=0)

# ordinary linear regression
from sklearn.linear_model import LinearRegression
f = LinearRegression()
f.fit(xtrain,ytrain) # all 13 X's
f.score(xtrain,ytrain)
f.score(xtest,ytest)
# selected features
fsel = ['crim','zn','indus']
#fsel = ['lstat','age','rm']
xtrain2 = xtrain[fsel]
xtest2 = xtest[fsel]
f.fit(xtrain2,ytrain)
f.score(xtest2,ytest)


# pcr
from sklearn.decomposition import PCA
pca = PCA(n_components=13)
pca.fit(xtrain)
xtrain_trans = pca.transform(xtrain)
xtest_trans = pca.transform(xtest)
f = LinearRegression()
f.fit(xtrain_trans,ytrain)
f.score(xtest_trans,ytest)

# after scaling
from sklearn.preprocessing import StandardScaler
s = StandardScaler()
s.fit(xtrain)
from sklearn.decomposition import PCA
pca = PCA(n_components=13)
pca.fit(s.transform(xtrain))
xtrain_trans = pca.transform(s.transform(xtrain))
xtest_trans = pca.transform(x.transform(xtest))
f = LinearRegression()
f.fit(xtrain_trans,ytrain)
f.score(xtest_trans,ytest)


