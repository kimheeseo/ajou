% Template matching using NCC

close all
clear
clc
keyboard

% Load first image
img0 = imread('einstein.jpg');
figure;
subplot(2,2,1);
imshow(img0, []);

% Designate the location of a template from the image
[x, y] = ginput(1);
x = round(x);
y = round(y);

% The size of the template: (2M+1)x(2M+1)
M = 9;
rectangle('Position', [x-M y-M 2*M+1 2*M+1], 'EdgeColor', 'r');

% Extract template (Note: (x,y) should not be close to border)
T = img0((y-M):(y+M), (x-M):(x+M));
subplot(2,2,2);
imshow(T, []);

% Load second image
%img1 = imread('einstein.jpg');
img1 = imread('einstein_tired.jpg');

% Do NCC matching
C = normxcorr2(T, img1);
subplot(2,2,3);
imshow(C, []);

% Find the location of the maximum score value
cmax = max(C(:));
[y2, x2] = find(C == cmax);

% Correct the location by subtracting off half the template size
y2 = y2-M;
x2 = x2-M;

% Show the location of the match in the second image
subplot(2,2,4);
imshow(img1, []);
rectangle('Position', [x2-M y2-M 2*M+1 2*M+1], 'EdgeColor', 'r');
fprintf('Score = %.4f at (x,y) = (%d,%d)\n', cmax, x2, y2);

% Show thresholded score
B = (C > 0.8);
figure;
imshow(B);

% Show score surface
figure;
surf(flipud(C));

