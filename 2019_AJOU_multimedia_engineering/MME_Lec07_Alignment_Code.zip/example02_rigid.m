close all
clear
clc
keyboard

% Load image
imgA = double(rgb2gray(imread('robotics_A.jpg')));
imgB = double(rgb2gray(imread('robotics_B.jpg')));

% Here are corresponding points (x;y)
pA = [221 413 416 228; ...
       31  20 304 308];
pB = [214 404 352 169; ...
        7  34 314 280];
N = size(pA,2);

A = zeros(2*N,4);
for i = 1:N
    A(2*(i-1)+1,:) = [pA(1,i) -pA(2,i) 1 0];
    A(2*(i-1)+2,:) = [pA(2,i)  pA(1,i) 0 1];
end
b = reshape(pB, [], 1);

x = A\b;

theta = acos(x(1));
tx = x(3);
ty = x(4);

%
[xi, yi] = meshgrid(1:640, 1:480);
xx =  cos(theta)*xi + sin(theta)*yi - tx;
yy = -sin(theta)*xi + cos(theta)*yi - ty;
foo = interp2(imgA, xx, yy);
figure(1);
imshow(uint8(imgA));
figure(2);
imshow(uint8(imgB));
figure(3);
imshow(uint8(foo));

