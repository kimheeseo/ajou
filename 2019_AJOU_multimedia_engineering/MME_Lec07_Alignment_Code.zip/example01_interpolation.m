close all
clear
clc
keyboard

% A useful function when using interp2
% xx is an array suitable for use as XI
% yy is an array suitable for use as YI
[xx, yy] = meshgrid(1:4, 1:3)

% result: just a copy of the image
im = double(imread('cameraman.tif'));
size(im)
[xi, yi] = meshgrid(1:256, 1:256);
foo = interp2(im, xi, yi);
figure(1);
imshow(uint8(foo));

% result: scale up by 2
foo = interp2(im, xi/2, yi/2);
figure(2);
imshow(uint8(foo));

% result: scale down by 2
foo = interp2(im, 2*xi, 2*yi);
figure(3);
imshow(uint8(foo));

%
foo = interp2(im, 2*xi-128, 2*yi-128);
figure(4);
imshow(uint8(foo));

% skip..
h = [1 0 128; 0 1 128; 0 0 1] * ...
    [1/2 0 0; 0 1/2 0 ; 0 0 1] * ...
    [1 0 -128; 0 1 -128; 0 0 1];
h = inv(h); % Take inverse for use with interp2
xx = (h(1,1)*xi+h(1,2)*yi+h(1,3))./(h(3,1)*xi+h(3,2)*yi+h(3,3));
yy = (h(2,1)*xi+h(2,2)*yi+h(2,3))./(h(3,1)*xi+h(3,2)*yi+h(3,3));
foo = interp2(im, xx, yy);
figure(5);
imshow(uint8(foo));

