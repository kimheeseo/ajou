close all
clear
clc
keyboard

% Here are corresponding points (x; y)
pA = [120 422 106 557; ...
       28   6 472 400];
pB = [201 501  81 536; ...
        6  28 420 462];

I1 = imread('book1.jpg');
I2 = imread('book2.jpg');

N = size(pA,2);
figure(1);
imshow(I1, []);
for i = 1:N
    rectangle('Position', [pA(1,i)-4 pA(2,i)-4 8 8], 'FaceColor', 'r');
end
figure(2);
imshow(I2, []);
for i = 1:N
    rectangle('Position', [pB(1,i)-4 pB(2,i)-4 8 8], 'FaceColor', 'r');
end

% Create matrices A and b
A = zeros(2*N, 6);
for i = 1:N
    A(2*(i-1)+1,:) = [pA(1,i) pA(2,i) 0       0       1 0];
    A(2*(i-1)+2,:) = [0       0       pA(1,i) pA(2,i) 0 1];
end
b = reshape(pB, [], 1);

% Calculate the transformation T from I1 to I2; i.e., p2 = T p1.
x = A\b;

% Unload values out of x and put into a 3x3 transformation matrix
T = [x(1) x(2) x(5); ...
     x(3) x(4) x(6); ...
     0    0    1];

% Get the inverse transformation from image2 to image1
invT = inv(T);

% Use interp2 to get transformed image1
[xi, yi] = meshgrid(1:640, 1:480);
xx = invT(1,1)*xi + invT(1,2)*yi + invT(1,3);
yy = invT(2,1)*xi + invT(2,2)*yi + invT(2,3);
foo1 = interp2(double(I1), xx, yy);
figure(3);
imshow(uint8(foo1));

% Warp image1 manually
foo2 = zeros(size(I2));
for x2 = 1:size(I2,2)
    for y2 = 1:size(I2,1)
        p2 = [x2; y2; 1];
        p1 = invT * p2;
        p1 = p1/p1(3);

        % We'll just pick the nearest point to p1 (better way is to
        % interpolate)
        x1 = round(p1(1));
        y1 = round(p1(2));

        if x1>0 && x1<size(I1,2) && y1>0 && y1<=size(I1,1)
            foo2(y2,x2) = I1(y1,x1);
        end
    end
end
figure(4);
imshow(uint8(foo2));

